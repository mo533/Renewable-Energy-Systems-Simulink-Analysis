clc; clear; close all;

% ================= Voltage ranges =================
V1 = linspace(110,258,300);   % Tx=10C, Sx=100
V2 = linspace(150,245,300);   % Tx=25C, Sx=125
V3 = linspace(175,234,300);   % Tx=40C, Sx=150

% ================= I–V curves (from your plots) =================
I1 = 4.9*(1 - (V1/258).^4);   % Tx=10C, Sx=100
I2 = 5.8*(1 - (V2/245).^4);   % Tx=25C, Sx=125
I3 = 6.2*(1 - (V3/234).^4);   % Tx=40C, Sx=150

% ================= Power =================
P1 = V1 .* I1;
P2 = V2 .* I2;
P3 = V3 .* I3;

% ================= Find MPPs =================
[Pmax1,k1] = max(P1); Vmp1 = V1(k1); Imp1 = I1(k1);
[Pmax2,k2] = max(P2); Vmp2 = V2(k2); Imp2 = I2(k2);
[Pmax3,k3] = max(P3); Vmp3 = V3(k3); Imp3 = I3(k3);

% ================= Plot =================
figure('Color','w'); hold on; grid on;

% ---- Current (left axis, dashed) ----
yyaxis left
plot(V1,I1,'b--','LineWidth',2)
plot(V2,I2,'r--','LineWidth',2)
plot(V3,I3,'g--','LineWidth',2)

plot(Vmp1,Imp1,'bo','LineWidth',2)
plot(Vmp2,Imp2,'ro','LineWidth',2)
plot(Vmp3,Imp3,'go','LineWidth',2)

ylabel('Current I (A)')

% ---- Power (right axis, solid) ----
yyaxis right
plot(V1,P1,'b','LineWidth',2)
plot(V2,P2,'r','LineWidth',2)
plot(V3,P3,'g','LineWidth',2)

plot(Vmp1,Pmax1,'bs','LineWidth',2)
plot(Vmp2,Pmax2,'rs','LineWidth',2)
plot(Vmp3,Pmax3,'gs','LineWidth',2)

ylabel('Power P (W)')

xlabel('Voltage V (V)')
title('Merged I–V (dashed) and P–V (solid) Characteristics')

legend( ...
 'I–V: 10°C,100','I–V: 25°C,125','I–V: 40°C,150', ...
 'MPP-I:10°C','MPP-I:25°C','MPP-I:40°C', ...
 'P–V: 10°C,100','P–V: 25°C,125','P–V: 40°C,150', ...
 'MPP-P:10°C','MPP-P:25°C','MPP-P:40°C', ...
 'Location','best');
