%% --- Data Input for WES (Tables 1 & 2) ---
 
% Table 1 Data: Effect of Wind Speed (Load Fixed at 200 kW)
v_T1 = [6, 8, 10, 12, 14]; % Wind Speed (m/s)
U_T1 = [60.79, 4363, 1996, 4945, 5013]; % Line-to-line Voltage (V)
Pout_W_T1 = [17.07, 87935, 18399, 112887, 116051]; % Output Power (W)
Pout_kW_T1 = Pout_W_T1 / 1000; % Output Power (kW)
Tm_T1_abs = [205.6, 365.5, 571.1, 822.3, 1119]; % Absolute Mechanic Torque (Nm)
 
% Table 2 Data: Effect of Load Change (Wind Speed Fixed at 10 m/s)
Pset_T2 = [1, 2, 3, 4, 5]; % Set Load Power (kW)
U_T2 = [587.6, 216.8, 182.3, 310.7, 2047]; % Line-to-line Voltage (V)
wG_T2 = [0.5444, 0.5169, 0.5068, 0.4849, 0.5760]; % Generator Speed (rad/s)
Pout_W_T2 = [7973, 2172, 2308, 8919, 483815]; % Output Power (W)
Pout_kW_T2 = Pout_W_T2 / 1000; % Output Power (kW)
 
 
%% --- Plotting Table 1 Graphs ---
 
% Figure 1: Output Power vs. Wind Speed
figure(1);
plot(v_T1, Pout_kW_T1, '-b^', 'LineWidth', 2);
title('Figure 1: WES Output Power vs. Wind Speed (P_{LOAD}=200 kW)');
xlabel('Wind Speed, v (m/s)');
ylabel('Output Power, P_{out} (kW)');
grid on;
set(gca, 'XTick', v_T1);
 
% Figure 2: Line-to-line Voltage vs. Wind Speed
figure(2);
plot(v_T1, U_T1, '-ro', 'LineWidth', 2);
hold on;
plot(v_T1, ones(size(v_T1)) * 5000, '--g', 'LineWidth', 1, 'DisplayName', 'Nominal Voltage (5000 V)');
hold off;
title('Figure 2: WES Line-to-line Voltage vs. Wind Speed (P_{LOAD}=200 kW)');
xlabel('Wind Speed, v (m/s)');
ylabel('Voltage, U (V)');
legend('Measured Voltage', 'Nominal Voltage', 'Location', 'SouthEast');
grid on;
set(gca, 'XTick', v_T1);
 
% Figure 3: Absolute Mechanical Torque vs. Wind Speed
figure(3);
plot(v_T1, Tm_T1_abs, '-m*', 'LineWidth', 2);
title('Figure 3: WES Absolute Mechanical Torque vs. Wind Speed (P_{LOAD}=200 kW)');
xlabel('Wind Speed, v (m/s)');
ylabel('Absolute Mechanical Torque, |T_{m}| (Nm)');
grid on;
set(gca, 'XTick', v_T1);
 
 
%% --- Plotting Table 2 Graphs ---
 
% Figure 4: Delivered Output Power vs. Set Load Power
figure(4);
plot(Pset_T2, Pout_kW_T2, '-b^', 'LineWidth', 2, 'DisplayName', 'Delivered Output Power (P_{out})');
hold on;
plot(Pset_T2, Pset_T2, '--r', 'LineWidth', 1, 'DisplayName', 'Set Load Power (P_{SET})'); 
hold off;
title('Figure 4: WES Delivered Output Power vs. Set Load Power (v=10 m/s)');
xlabel('Set Load Power, P_{SET} (kW)');
ylabel('Power (kW)');
legend('show', 'Location', 'NorthWest');
grid on;
set(gca, 'XTick', Pset_T2);
 
% Figure 5: Line-to-line Voltage vs. Set Load Power
figure(5);
plot(Pset_T2, U_T2, '-ro', 'LineWidth', 2);
title('Figure 5: WES Line-to-line Voltage vs. Set Load Power (v=10 m/s)');
xlabel('Set Load Power, P_{SET} (kW)');
ylabel('Voltage, U (V)');
grid on;
set(gca, 'XTick', Pset_T2);
 
% Figure 6: Generator Speed vs. Set Load Power
figure(6);
plot(Pset_T2, wG_T2, '-g*', 'LineWidth', 2);
title('Figure 6: WES Generator Speed vs. Set Load Power (v=10 m/s)');
xlabel('Set Load Power, P_{SET} (kW)');
ylabel('Generator Speed, \omega_G (rad/s)');
grid on;
set(gca, 'XTick', Pset_T2);
